# -*- coding: utf-8 -*-
import re, os, json
os.chdir(os.path.dirname(os.path.abspath(__file__)))
S='../site'
def rd(f): return open(f'{S}/{f}',encoding='utf8').read()
def wr(f,s): open(f'{S}/{f}','w',encoding='utf8').write(s)
TR=[]
def T(fr,en,es): TR.append((fr,en,es)); return fr

# ---------- A) pages programmes : Pour qui / Ce que tu reçois / pack / matériel ----------
info=('<section class="formules infoprog"><div class="fcols">'
 '<div class="fcol"><h4>'+T('POUR QUI ?','WHO IS IT FOR?','¿PARA QUIÉN?')+'</h4><ul>'
 '<li>'+T("Tous les niveaux : débutant, intermédiaire ou avancé.","All levels: beginner, intermediate or advanced.","Todos los niveles: principiante, intermedio o avanzado.")+'</li>'
 '<li>'+T("À partir de 14 ans, avec l'accord d'un parent avant 18 ans. Interdit avant 14 ans.","From age 14, with a parent's consent before 18. Not allowed under 14.","A partir de 14 años, con el consentimiento de un padre o madre antes de los 18. Prohibido antes de los 14.")+'</li>'
 '<li>'+T("Après 50 ans, les PDF restent disponibles, mais je recommande fortement le coaching sur mesure : le corps change, et j'adapte l'approche à ton âge et à ta condition.","After 50, the PDFs remain available, but I strongly recommend tailored coaching: the body changes, and I adapt the approach to your age and condition.","A partir de los 50 años, los PDF siguen disponibles, pero recomiendo encarecidamente el coaching a medida: el cuerpo cambia y adapto el enfoque a tu edad y a tu condición.")+'</li></ul>'
 '<p style="margin:10px 0 0"><a class="btn alt" href="coaching-sur-mesure.html">'+T("VOIR LE COACHING SUR MESURE","SEE TAILORED COACHING","VER EL COACHING A MEDIDA")+'</a></p></div>'
 '<div class="fcol"><h4>'+T('CE QUE TU REÇOIS','WHAT YOU GET','LO QUE RECIBES')+'</h4><ul>'
 '<li>'+T("Un programme PDF de 2 mois minimum","A PDF program of 2 months minimum","Un programa en PDF de 2 meses como mínimo")+'</li>'
 '<li>'+T("Les exercices expliqués, les charges et les pourcentages","Exercises explained, loads and percentages","Los ejercicios explicados, las cargas y los porcentajes")+'</li>'
 '<li>'+T("Avec suivi : un tableau de suivi (Google Sheet) et un contact WhatsApp","With follow-up: a tracking table (Google Sheet) and WhatsApp contact","Con seguimiento: una tabla de seguimiento (Google Sheet) y contacto por WhatsApp")+'</li>'
 '<li>'+T("Sans suivi : pas de tableau de suivi","Without follow-up: no tracking table","Sin seguimiento: sin tabla de seguimiento")+'</li></ul></div></div></section>')
pack=('<p class="packnote">'+T("Pack : ajoute la nutrition à ton programme pour 5 € par mois au lieu de 10 €.","Pack: add nutrition to your program for €5 per month instead of €10.","Pack: añade la nutrición a tu programa por 5 € al mes en lugar de 10 €.")+' <a href="nutrition.html">'+T("Voir la nutrition","See nutrition","Ver la nutrición")+'</a></p>')
mat_salle=T("Matériel : celui d'une salle de musculation classique.","Equipment: that of a standard gym.","Material: el de un gimnasio normal.")
mat_maison=T("Matériel : aucun obligatoire. Au besoin : élastiques, bouteilles d'eau, livres, chaise, lit ou surface solide. Le programme explique tout.","Equipment: none required. If needed: resistance bands, water bottles, books, a chair, a bed or a solid surface. The program explains everything.","Material: ninguno obligatorio. Si hace falta: bandas elásticas, botellas de agua, libros, una silla, una cama o una superficie sólida. El programa lo explica todo.")
maison_keys=('Détente à la maison ou en extérieur','Performance à la maison ou en extérieur','Home Body')
for f in ('force','detente','performance-athletique','musculation'):
    s=rd(f+'.html')
    if 'infoprog' in s: continue
    # matériel dans chaque carte
    def addmat(m):
        art=m.group(0); key=re.search(r'data-pay="([^"]+)"',art).group(1)
        li='<li>'+(mat_maison if key in maison_keys else mat_salle)+'</li>'
        return art.replace('</ul>',li+'</ul>',1)
    s=re.sub(r'<article class="card prog">.*?</article>',addmat,s,flags=re.S)
    s=s.replace('<div class="grid progs"',info+'\n  '+pack+'\n  <div class="grid progs"',1)
    wr(f+'.html',s)

# ---------- B) page Coaching sur mesure ----------
page=rd('creation-site.html')
def opt(fr,en,es): return '<option>'+T(fr,en,es)+'</option>'
main=('<main class="wrap legal-page">\n  <div class="eyebrow">'+T("COACHING SUR MESURE","TAILORED COACHING","COACHING A MEDIDA")+'</div>\n  <h1>'+T("PRÉPARATION PHYSIQUE","PHYSICAL PREPARATION","PREPARACIÓN FÍSICA")+'</h1>\n'
 '  <p class="muted" style="max-width:760px">'+T("Un accompagnement construit pour toi : musculation, préparation physique, quel que soit ton sport. Ce n'est pas un PDF générique : tout est adapté à ton niveau, à ton âge, à ta condition et à tes objectifs.","An approach built for you: strength training, physical preparation, whatever your sport. This is not a generic PDF: everything is adapted to your level, age, condition and goals.","Un acompañamiento construido para ti: musculación, preparación física, sea cual sea tu deporte. No es un PDF genérico: todo se adapta a tu nivel, tu edad, tu condición y tus objetivos.")+'</p>\n'
 '  <div class="pills" style="margin:16px 0"><span class="pill">'+T("30 € / mois","€30 / month","30 € / mes")+'</span><span class="pill pill-blue">'+T("Sans durée minimale","No minimum duration","Sin duración mínima")+'</span><span class="pill pill-grey">'+T("Tous niveaux, dès 14 ans","All levels, from age 14","Todos los niveles, desde los 14 años")+'</span></div>\n'
 '  <section class="formules"><div class="fcols"><div class="fcol on"><h4>'+T("LE SUIVI","FOLLOW-UP","EL SEGUIMIENTO")+'</h4><p>'+T("Même fonctionnement que le coaching course à pied : un Google Sheet de suivi, des échanges sur WhatsApp et des appels.","Same way of working as the running coaching: a Google Sheet to track your sessions, WhatsApp exchanges and calls.","Mismo funcionamiento que el coaching de carrera a pie: una hoja de Google para el seguimiento, intercambios por WhatsApp y llamadas.")+'</p></div>'
 '<div class="fcol"><h4>'+T("RECOMMANDÉ DÈS 50 ANS","RECOMMENDED FROM AGE 50","RECOMENDADO A PARTIR DE LOS 50 AÑOS")+'</h4><p>'+T("Le corps change avec l'âge : j'adapte l'approche à ta condition, pour que ça te corresponde vraiment.","The body changes with age: I adapt the approach to your condition so it truly fits you.","El cuerpo cambia con la edad: adapto el enfoque a tu condición para que realmente se ajuste a ti.")+'</p></div></div></section>\n'
 '  <section class="formules" id="demande"><h2>'+T("Dis-moi tout","Tell me everything","Cuéntamelo todo")+'</h2><p class="muted">'+T("Réponds à ces questions et dis-moi ce que tu attends de moi. Plus tu es précis, mieux je construis ton accompagnement.","Answer these questions and tell me what you expect from me. The more precise you are, the better I can build your coaching.","Responde a estas preguntas y dime qué esperas de mí. Cuanto más preciso seas, mejor construiré tu acompañamiento.")+'</p>'
 '<form class="cmform" id="cmForm" onsubmit="return false">'
 '<label>'+T("Ton sport (ou aucun)","Your sport (or none)","Tu deporte (o ninguno)")+'<input id="cmSport" placeholder="'+T("Ex. : basket, football, aucun…","E.g. basketball, football, none…","Ej.: baloncesto, fútbol, ninguno…")+'"></label>'
 '<label>'+T("Ton niveau","Your level","Tu nivel")+'<select id="cmNiveau">'+opt("Débutant","Beginner","Principiante")+opt("Intermédiaire","Intermediate","Intermedio")+opt("Avancé","Advanced","Avanzado")+'</select></label>'
 '<label>'+T("Séances par semaine","Sessions per week","Sesiones por semana")+'<select id="cmSeances">'+opt("1 à 2","1 to 2","1 a 2")+opt("3 à 4","3 to 4","3 a 4")+opt("5 ou plus","5 or more","5 o más")+'</select></label>'
 '<label>'+T("Où t'entraînes-tu ?","Where do you train?","¿Dónde entrenas?")+'<select id="cmLieu">'+opt("En salle de musculation","In a gym","En el gimnasio")+opt("À la maison ou en extérieur","At home or outdoors","En casa o al aire libre")+opt("Les deux","Both","Ambos")+'</select></label>'
 '<label class="full">'+T("Blessures ou contraintes","Injuries or constraints","Lesiones o limitaciones")+'<input id="cmBlessures" placeholder="'+T("Blessures, douleurs, emploi du temps chargé…","Injuries, pain, busy schedule…","Lesiones, dolores, horario cargado…")+'"></label>'
 '<label class="full">'+T("Ton objectif (saison, sport…)","Your goal (season, sport…)","Tu objetivo (temporada, deporte…)")+'<input id="cmObjectif" placeholder="'+T("Ce que tu veux atteindre","What you want to achieve","Lo que quieres conseguir")+'"></label>'
 '<label class="full">'+T("Tes attentes","Your expectations","Tus expectativas")+'<textarea id="cmAttentes" rows="5" placeholder="'+T("Dis-moi tout : tes attentes, ce que tu aimerais, ce que tu attends de moi…","Tell me everything: your expectations, what you would like, what you expect from me…","Cuéntamelo todo: tus expectativas, lo que te gustaría, lo que esperas de mí…")+'"></textarea></label></form>'
 '<p class="paymsg" id="cmMsg"></p>'
 '<div class="buttons"><button type="button" class="btn alt" id="cmSend">'+T("ENVOYER MES RÉPONSES SUR WHATSAPP","SEND MY ANSWERS ON WHATSAPP","ENVIAR MIS RESPUESTAS POR WHATSAPP")+'</button>'
 '<a class="btn" type="button" data-pay="Coaching sur mesure, 1 mois" data-prix="30 €">'+T("PAYER 30 € / MOIS","PAY €30 / MONTH","PAGAR 30 € / MES")+'</a></div>'
 '<p class="muted" style="font-size:13px;margin-top:12px">'+T("Envoie tes réponses sur WhatsApp, puis paie ton premier mois. Tes réponses sont aussi jointes au message envoyé avec le paiement.","Send your answers on WhatsApp, then pay your first month. Your answers are also attached to the message sent with the payment.","Envía tus respuestas por WhatsApp y luego paga tu primer mes. Tus respuestas también se adjuntan al mensaje enviado con el pago.")+'</p></section>\n</main>')
main=main.replace("Mes réponses sont aussi jointes","Tes réponses sont aussi jointes")
TR[-1]=(TR[-1][0].replace("Mes réponses sont aussi jointes","Tes réponses sont aussi jointes"),)+TR[-1][1:] if False else TR[-1]
page=re.sub(r'<main.*?</main>',lambda m:main,page,count=1,flags=re.S)
wr('coaching-sur-mesure.html',page)

# ---------- C) programmes + accueil : nouvelle carte ----------
s=rd('programmes.html')
if 'coaching-sur-mesure' not in s:
    card='<article class="card wide"><img src="assets/performance.webp" alt="Coaching sur mesure"><div class="card-body"><span class="num">06</span><h3>'+T("COACHING SUR MESURE","TAILORED COACHING","COACHING A MEDIDA")+'</h3><p class="muted">'+T("Préparation physique et musculation, 30 € par mois","Physical preparation and strength training, €30 per month","Preparación física y musculación, 30 € al mes")+'</p><a href="coaching-sur-mesure.html">DÉCOUVRIR →</a></div></article>'
    s=s.replace('\n</div>\n\n<section class="ctaband siteband">',"\n  "+card+'\n</div>\n\n<section class="ctaband siteband">',1)
    assert 'coaching-sur-mesure' in s
    wr('programmes.html',s)
s=rd('index.html')
if 'coaching-sur-mesure' not in s:
    h='<a class="hpcard hpwide" href="coaching-sur-mesure.html"><img loading="lazy" src="assets/performance.webp" alt=""><div><h3>'+T("COACHING SUR MESURE","TAILORED COACHING","COACHING A MEDIDA")+'</h3><p>'+T("Préparation physique et musculation, un accompagnement personnalisé","Physical preparation and strength training, personalised coaching","Preparación física y musculación, un acompañamiento personalizado")+'</p><span class="hpprice">'+T("30 € / mois","€30 / month","30 € / mes")+'</span></div></a>'
    s=s.replace('</div></section>\n<section class="section wrap" id="quiz">',h+'</div></section>\n<section class="section wrap" id="quiz">',1)
    assert 'coaching-sur-mesure' in s
    wr('index.html',s)

# ---------- D) CSS + JS + serveur + outils ----------
css=rd('style.css')
if 'v62' not in css:
    css+='''
/* v62 : coaching sur mesure, pack nutrition, pour qui */
.packnote{margin:14px 0 0;padding:12px 16px;border:1px dashed #237344;border-radius:10px;color:#d3dcd8;font-size:15px}
.packnote a{color:var(--green);font-weight:800;text-decoration:underline;margin-left:6px}
.infoprog{margin-top:16px}.infoprog ul{margin:0;padding-left:20px;color:#c4cdca;font-size:14.5px}.infoprog li{margin-bottom:6px}
.cmform{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin:16px 0}
.cmform label{display:flex;flex-direction:column;gap:6px;font-size:13px;color:var(--muted);font-weight:700}
.cmform label.full{grid-column:1/-1}
.cmform input,.cmform select,.cmform textarea{width:100%;background:#070a09;border:1px solid #35423e;color:#fff;padding:12px;border-radius:8px;font:inherit;font-size:15px;font-weight:400}
@media(max-width:720px){.cmform{grid-template-columns:1fr}}
.hpwide{grid-column:1/-1;flex-direction:row}.hpwide img{width:34%;height:auto;min-height:130px}.hpwide div{flex:1;align-self:center}
@media(max-width:900px){.hpwide{flex-direction:column}.hpwide img{width:100%;height:130px}}
'''
    wr('style.css',css)
js=rd('script.js')
if 'HC_EXTRA' not in js:
    js=js.replace("    return 'https://wa.me/33767927163?text=' + encodeURIComponent(msg);\n  }\n  /* affiche","    if(window.HC_EXTRA) msg += '\\n\\n' + window.HC_EXTRA();\n    return 'https://wa.me/33767927163?text=' + encodeURIComponent(msg);\n  }\n  /* affiche",1)
    js=js.replace("'\\n\\nPeux-tu m\\'envoyer ton IBAN ?';","'\\n\\nPeux-tu m\\'envoyer ton IBAN ?' + (window.HC_EXTRA ? '\\n\\n' + window.HC_EXTRA() : '');",1)
    assert js.count('HC_EXTRA')>=2, js.count('HC_EXTRA')
    js+='''
/* HC_EXTRA : formulaire du coaching sur mesure (réponses jointes au paiement et à WhatsApp) */
(function(){
  var f = document.getElementById('cmForm'); if(!f) return;
  function v(id){ var e = document.getElementById(id); return e ? e.value.trim() : ''; }
  window.HC_EXTRA = function(){
    return 'COACHING SUR MESURE - mes réponses :\\nSport : ' + (v('cmSport') || '-') + '\\nNiveau : ' + v('cmNiveau') + '\\nSéances par semaine : ' + v('cmSeances') +
      '\\nLieu : ' + v('cmLieu') + '\\nBlessures / contraintes : ' + (v('cmBlessures') || '-') + '\\nObjectif : ' + v('cmObjectif') + '\\nMes attentes : ' + v('cmAttentes');
  };
  var msg = document.getElementById('cmMsg');
  function valide(){
    if(!v('cmObjectif') || !v('cmAttentes')){
      msg.textContent = (window.hcT ? window.hcT('Indique ton objectif et tes attentes pour continuer.') : 'Indique ton objectif et tes attentes pour continuer.');
      try{ msg.scrollIntoView({block:'center', behavior:'smooth'}); }catch(e){}
      return false;
    }
    msg.textContent = ''; return true;
  }
  document.getElementById('cmSend').addEventListener('click', function(){
    if(!valide()) return;
    window.open('https://wa.me/33767927163?text=' + encodeURIComponent('Bonjour Victor, je souhaite un coaching sur mesure.\\n\\n' + window.HC_EXTRA()), '_blank', 'noopener');
  });
  var pay = document.querySelector('[data-pay]');
  if(pay) pay.addEventListener('click', function(e){ if(!valide()){ e.stopImmediatePropagation(); e.preventDefault(); } }, true);
})();
'''
    wr('script.js',js)
TR.append(("Indique ton objectif et tes attentes pour continuer.","Enter your goal and your expectations to continue.","Indica tu objetivo y tus expectativas para continuar."))
p='../functions/api/[[path]].js'; s=open(p,encoding='utf8').read()
if 'Coaching sur mesure' not in s:
    s=s.replace('  "Coaching course à pied, 2 mois": 30,','  "Coaching sur mesure, 1 mois": 30,\n  "Coaching course à pied, 2 mois": 30,',1); open(p,'w',encoding='utf8').write(s)
sp=open('seo.py',encoding='utf8').read()
if "'coaching-sur-mesure'" not in sp:
    sp=sp.replace("'coaching','force'","'coaching','coaching-sur-mesure','force'",1)
    sp=sp.replace("'creation-site':(",""""'coaching-sur-mesure':("Coaching sur mesure en préparation physique | Hybride Coaching","Coaching personnalisé en préparation physique et musculation, 30 € par mois, sans durée minimale. Google Sheet, WhatsApp et appels. Par Victor Castillo.",
 "Tailored Physical Preparation Coaching | Hybride Coaching","Personalised coaching in physical preparation and strength training, €30 per month, no minimum duration. Google Sheet, WhatsApp and calls. By Victor Castillo.",
 "Coaching a medida de preparación física | Hybride Coaching","Coaching personalizado de preparación física y musculación, 30 € al mes, sin duración mínima. Google Sheet, WhatsApp y llamadas. Por Victor Castillo."),
'creation-site':(""".replace('"'+"'coaching",'' ) if False else "'coaching-sur-mesure':(\"Coaching sur mesure en préparation physique | Hybride Coaching\",\"Coaching personnalisé en préparation physique et musculation, 30 € par mois, sans durée minimale. Google Sheet, WhatsApp et appels. Par Victor Castillo.\",\n \"Tailored Physical Preparation Coaching | Hybride Coaching\",\"Personalised coaching in physical preparation and strength training, €30 per month, no minimum duration. Google Sheet, WhatsApp and calls. By Victor Castillo.\",\n \"Coaching a medida de preparación física | Hybride Coaching\",\"Coaching personalizado de preparación física y musculación, 30 € al mes, sin duración mínima. Google Sheet, WhatsApp y llamadas. Por Victor Castillo.\"),\n'creation-site':(",1)
    open('seo.py','w',encoding='utf8').write(sp)
en=open('engine.js',encoding='utf8').read()
if 'coaching-sur-mesure' not in en:
    en=en.replace("'coaching','force'","'coaching','coaching-sur-mesure','force'",1); open('engine.js','w',encoding='utf8').write(en)
h2=rd('_headers')
ex=open('extras.py',encoding='utf8').read(); m='# ==== v62 (genere) ===='
if m in ex: ex=ex[:ex.index(m)]
seen=set(); L=[]
for t in TR:
    if t[0] in seen: continue
    seen.add(t[0]); L.append('('+','.join(json.dumps(x,ensure_ascii=False) for x in t)+'),')
ex+='\n'+m+'\nEXACT += [\n'+'\n'.join(L)+'\n]\n'
open('extras.py','w',encoding='utf8').write(ex)
print('ok',len(TR))
