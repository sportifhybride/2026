# -*- coding: utf-8 -*-
import re, os, json
os.chdir(os.path.dirname(os.path.abspath(__file__)))
S='../site'
def rd(f): return open(f'{S}/{f}',encoding='utf8').read()
def wr(f,s): open(f'{S}/{f}','w',encoding='utf8').write(s)
TR=[]
def T(fr,en,es): TR.append((fr,en,es)); return fr

# A) hub coaching.html
c=rd('coaching.html')
if 'class="hub"' not in c:
    old='<div class="eyebrow">PROGRAMMES · COURSE À PIED</div>\n<h1>COACHING PERSONNALISÉ</h1>\n'
    assert old in c
    hub=('<div class="eyebrow">'+T('COACHING','COACHING','COACHING')+'</div>\n<h1>COACHING PERSONNALISÉ</h1>\n'
     '<p class="muted hubintro">'+T("Un accompagnement sur mesure avec moi. Choisis ce qui correspond à ton objectif.","Tailored coaching with me. Choose what fits your goal.","Un acompañamiento a medida conmigo. Elige lo que encaja con tu objetivo.")+'</p>\n'
     '<div class="hub">'
     '<a class="hubcard hub-run" href="#course"><img src="assets/running.webp" alt=""><div><h2>'+T('COURSE À PIED','RUNNING','CARRERA A PIE')+'</h2>'
     '<p>'+T("Un plan construit sur la durée, du 5 km au marathon sur route, avec suivi quotidien.","A plan built over time, from 5 km to road marathon, with daily follow-up.","Un plan construido a largo plazo, del 5 km al maratón en ruta, con seguimiento diario.")+'</p>'
     '<span class="hubprice">'+T('Dès 30 €','From €30','Desde 30 €')+'</span><span class="hubgo">'+T('VOIR LES OFFRES ↓','SEE THE OFFERS ↓','VER LAS OFERTAS ↓')+'</span></div></a>'
     '<a class="hubcard hub-prep" href="coaching-sur-mesure.html"><img src="assets/performance.webp" alt=""><div><h2>'+T('PRÉPARATION PHYSIQUE','PHYSICAL PREPARATION','PREPARACIÓN FÍSICA')+'</h2>'
     '<p>'+T("Un accompagnement personnalisé en préparation physique et musculation, sans durée minimale.","Personalised support in physical preparation and strength training, no minimum duration.","Un acompañamiento personalizado en preparación física y musculación, sin duración mínima.")+'</p>'
     '<span class="hubprice">'+T('30 € / mois','€30 / month','30 € / mes')+'</span><span class="hubgo">'+T('DÉCOUVRIR →','DISCOVER →','DESCUBRIR →')+'</span></div></a>'
     '</div>\n'
     '<div class="eyebrow" id="course" style="margin-top:46px">'+T('COACHING · COURSE À PIED','COACHING · RUNNING','COACHING · CARRERA A PIE')+'</div>\n<h2 class="hubh2">'+T('COURSE À PIED','RUNNING','CARRERA A PIE')+'</h2>\n')
    c=c.replace(old,hub,1); wr('coaching.html',c)

# B) programmes : retirer carte 06
p=rd('programmes.html')
p2=re.sub(r'\n?\s*<article class="card wide"><img src="assets/performance.webp" alt="Coaching sur mesure">.*?</article>','',p,flags=re.S)
wr('programmes.html',p2)

# C) accueil : une seule carte
h=rd('index.html')
h=re.sub(r'<a class="hpcard hpwide" href="coaching-sur-mesure.html">.*?</a>','',h,flags=re.S)
newc=('<a class="hpcard" href="coaching.html"><img loading="lazy" src="assets/running.webp" alt=""><div><h3>'+'COACHING PERSONNALISÉ'+'</h3><p>'+T('Course à pied ou préparation physique, un accompagnement sur mesure','Running or physical preparation, tailored coaching','Carrera a pie o preparación física, un acompañamiento a medida')+'</p><span class="hpprice">Dès 30 €</span></div></a>')
h=re.sub(r'<a class="hpcard" href="coaching.html">.*?</a>',lambda m:newc,h,count=1,flags=re.S)
wr('index.html',h)

# D) classes de famille
for f,k in [('force','force'),('detente','detente'),('performance-athletique','performance'),('musculation','muscu'),('nutrition','nutrition')]:
    s=rd(f+'.html')
    if 'fam-' not in s:
        s=s.replace('</head><body>','</head><body class="fam-'+k+'">',1); wr(f+'.html',s)

# E) CSS
css=rd('style.css')
if '/* v63 debut */' not in css:
    css+='''
/* v63 debut : hub coaching, couleurs par famille, textes lisibles */
.hubintro{font-size:16px;max-width:640px;margin:10px 0 24px}
.hub{display:grid;grid-template-columns:1fr 1fr;gap:20px}
.hubcard{display:flex;flex-direction:column;background:var(--panel);border:1px solid var(--line);border-radius:16px;overflow:hidden;transition:transform .25s,border-color .25s,box-shadow .25s}
.hubcard img{width:100%;height:230px;object-fit:cover}
.hubcard div{padding:22px 24px 26px;display:flex;flex-direction:column;flex:1}
.hubcard h2{margin:0 0 8px;font-size:clamp(26px,3vw,36px);line-height:1.05}
.hubcard p{margin:0 0 16px;color:#c3ccc9;font-size:16px;line-height:1.5}
.hubprice{font-weight:900;font-size:20px;color:var(--green);margin-top:auto}
.hubgo{display:inline-block;margin-top:10px;font-weight:900;font-size:14px;letter-spacing:.06em}
.hub-run:hover{border-color:var(--green);box-shadow:0 8px 30px #35ff8422}
.hub-prep{border-color:#2a4a6e}.hub-prep .hubprice,.hub-prep .hubgo{color:#5fb0ff}.hub-prep:hover{border-color:#5fb0ff;box-shadow:0 8px 30px #278cff22}
.hubh2{margin:6px 0 0}
#course{scroll-margin-top:90px}
@media(max-width:800px){.hub{grid-template-columns:1fr}.hubcard img{height:180px}}
/* familles : une couleur par famille de programme */
body.fam-force main{--green:#ff5a66}
body.fam-detente main{--green:#42b8ff}
body.fam-muscu main{--green:#c98aff}
body.fam-nutrition main{--green:#ffb43a}
body.fam-force main .pill:not(.pill-blue):not(.pill-track):not(.pill-grey):not(.pill-soon){background:#2a1013;border-color:#8a2c35}
body.fam-detente main .pill:not(.pill-blue):not(.pill-track):not(.pill-grey):not(.pill-soon){background:#0c1c2a;border-color:#245f8a}
body.fam-muscu main .pill:not(.pill-blue):not(.pill-track):not(.pill-grey):not(.pill-soon){background:#1d1228;border-color:#6b3f93}
body.fam-nutrition main .pill:not(.pill-blue):not(.pill-track):not(.pill-grey):not(.pill-soon){background:#261b08;border-color:#8a6416}
body.fam-force main .card.prog:hover{border-color:#ff5a66}body.fam-detente main .card.prog:hover{border-color:#42b8ff}body.fam-muscu main .card.prog:hover{border-color:#c98aff}body.fam-nutrition main .card.prog:hover{border-color:#ffb43a}
.hpcard[href="force.html"] h3{color:#ff5a66}.hpcard[href="detente.html"] h3{color:#42b8ff}.hpcard[href="musculation.html"] h3{color:#c98aff}.hpcard[href="nutrition.html"] h3{color:#ffb43a}.hpcard[href="performance-athletique.html"] h3{color:#35ff84}.hpcard[href="coaching.html"] h3{color:#5fb0ff}
.hpcard[href="force.html"]:hover{border-color:#ff5a66}.hpcard[href="detente.html"]:hover{border-color:#42b8ff}.hpcard[href="musculation.html"]:hover{border-color:#c98aff}.hpcard[href="nutrition.html"]:hover{border-color:#ffb43a}.hpcard[href="coaching.html"]:hover{border-color:#5fb0ff}
/* petits textes plus lisibles */
:root{--muted:#c0cac6}
.muted{font-size:15px}
.notice{color:#b3bdb9;font-size:14px}
.footer{font-size:14px}
.proof small{color:#aab5b1;font-size:13.5px}
.brand small{font-size:11.5px}
.eyebrow{font-size:13px}
.card a{font-size:14px}
.offre p,.offre .eco,.offre .prix span{font-size:14px}
.avis figcaption,.pfig figcaption,.sheetfig figcaption,.zonehint,.tool label,.auth label{font-size:14px}
.payconsent{font-size:13.5px;color:#d0d8d5}
.pill{font-size:13.5px}
.hpcard p{color:#cfd7d4;font-size:15px}
.packnote,.infoprog li,.more li{font-size:15px}
/* v63 fin */
/* v63 mouvement debut : supprimer ce bloc (et celui de script.js) pour tout enlever */
@media(prefers-reduced-motion:no-preference){
.rv{opacity:0;transform:translateY(14px);transition:opacity .6s ease,transform .6s ease}
.rv.rv-in{opacity:1;transform:none}
.btn{transition:transform .18s,box-shadow .18s,filter .18s}
.btn:hover{transform:translateY(-2px);filter:brightness(1.08)}
.card,.philcard,.offre,.hubcard,.hpcard{transition:transform .25s,border-color .25s,box-shadow .25s}
.card:hover,.philcard:hover,.hubcard:hover{transform:translateY(-3px)}
.hubcard img,.hpcard img{transition:transform .5s ease}
.hubcard:hover img,.hpcard:hover img{transform:scale(1.04)}
.hubcard,.hpcard{overflow:hidden}
}
/* v63 mouvement fin */
'''
    wr('style.css',css)

# F) JS mouvement
js=rd('script.js')
if 'v63 mouvement' not in js:
    js+='''
/* v63 mouvement debut : supprimer ce bloc pour enlever les animations */
(function(){try{
if(window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches)return;
if(!('IntersectionObserver' in window))return;
var els=[].slice.call(document.querySelectorAll('main .section,main .hpcard,main .card,main .philcard,main .offre,main .hubcard,main .formules,main .steps3>*,main .hpq,main .ctaband'));
var h=innerHeight;
els=els.filter(function(e){return e.getBoundingClientRect().top>h*0.9&&!e.closest('#paywall')});
els.forEach(function(e){e.classList.add('rv')});
var io=new IntersectionObserver(function(es){es.forEach(function(x){if(x.isIntersecting){x.target.classList.add('rv-in');io.unobserve(x.target)}})},{threshold:0.08,rootMargin:'0px 0px -4% 0px'});
els.forEach(function(e){io.observe(e)});
setTimeout(function(){els.forEach(function(e){e.classList.add('rv-in')})},6000);
addEventListener('beforeprint',function(){els.forEach(function(e){e.classList.add('rv-in')})});
}catch(e){}})();
/* v63 mouvement fin */
'''
    wr('script.js',js)

ex=open('extras.py',encoding='utf8').read(); m='# ==== v63 (genere) ===='
if m in ex: ex=ex[:ex.index(m)]
seen=set(); L=[]
for t in TR:
    if t[0] in seen: continue
    seen.add(t[0]); L.append('('+','.join(json.dumps(x,ensure_ascii=False) for x in t)+'),')
ex+='\n'+m+'\nEXACT += [\n'+'\n'.join(L)+'\n]\n'
open('extras.py','w',encoding='utf8').write(ex)
print('ok',len(TR))
